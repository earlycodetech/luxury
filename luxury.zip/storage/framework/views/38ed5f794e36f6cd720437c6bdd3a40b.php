
<?php $__env->startSection('content'); ?>
    <section>
        <div class="container my-5">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1 class="text-center">Create New Room</h1>

                <a href="" class="btn btn-primary">
                    All Rooms
                </a>
            </div>
            <div class="card bg-white border-0 shadow mx-auto" style="max-width: 800px;">
                <div class="card-body">


                    <?php if($message = Session::get('success')): ?>
                        <p class="text-success fw-bold text-center mb-1">
                            <?php echo e($message); ?>

                        </p>
                    <?php endif; ?>
                    <form action="<?php echo e(route('admin.room.store')); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="mb-3">
                            <label for="" class="form-labe">Room Name</label>
                            <input type="text" name="room_name" class="form-control">
                            <?php $__errorArgs = ['room_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger fw-bold text-center mb-1">
                                    <?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-labe">Available Room</label>
                            <input type="number" name="available_rooms" class="form-control">
                            <?php $__errorArgs = ['available_rooms'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger fw-bold text-center mb-1">
                                    <?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="mb-3">
                            <label for="" class="form-labe">Room Price</label>
                            <input type="number" name="room_price" class="form-control">
                            <?php $__errorArgs = ['room_price'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <p class="text-danger fw-bold text-center mb-1">
                                    <?php echo e($message); ?>

                                </p>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="text-center mb-3">
                            <button class="btn btn-primary">
                                Create Room
                            </button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Owner\Desktop\Workspace\Earlycode\luxury\resources\views/rooms/create.blade.php ENDPATH**/ ?>